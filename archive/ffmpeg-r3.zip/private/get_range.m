function range = get_range(range,units,infile,fs_in)
%GET_RANGE   Convert range from discrete-time to continuous-time
%   GET_RANGE(RANGE, UNITS, INFILE) converts range specified in frames or
%   samples to seconds. If RANGE is a two-element vector, it defines [START
%   END]; else if RANGE is a scalar, it indicates the duration starting
%   from the beginning. UNITS may be one of 'seconds', 'frames', or
%   'samples'. If 'seconds', no conversion will take place. If UNITS =
%   'frame', RANGE is converted using the first video frame rate. If UNITS
%   = 'samples', RANGE is converted using the first audio sampling rate.
%   RANGE values in a discrete-time units are in one-base indices. The
%   video frame rate or audio sampling rate is obtained from the media file
%   specified by INFILE string.
%
%   GET_RANGE(RANGE, UNITS, INFILE, FS_IN) is used if '-r' flag is used on
%   the input to change the frame/sampling rate. FS_IN to pass in the
%   forced rate. If FS_IN is empty, the original rates from INFILE will be
%   used.
%
%   *******************INTERNAL FUNCTION WARNING***************************
%   There is no input argument check!!!

% Copyright 2015 Takeshi Ikuma
% History:
% rev. - : (04-06-2015) original release

narginchk(3,4);

N = numel(range);
   
% if range not specified, nothing to do
if isempty(range), return; end

if strcmp(units,'seconds')
   fs_in = 1;
else
   if nargin<4, fs_in = []; end
   
   if N==1 && range(1)==1
      error('Span of Range must be greater than 0.');
   elseif N==2 && range(1)==0
      error('Sample/frame based Range must be given with 1-based indices.');
   end
   
   if strcmpi(units,'frames') % video frame
      if isempty(fs_in)
         fs_in = getframerate(infile);
      end
   elseif strcmpi(units,'samples')
      fs_in = getsamplerate(infile);
   else
      error('Invalid Units value specified.');
   end
end

if N==1
   range = [0 range/fs_in];
else
   range = (range(:).'-[1 0])/fs_in;
end
