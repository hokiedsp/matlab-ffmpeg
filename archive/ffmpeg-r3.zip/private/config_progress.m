function [glopts,startfcn,cleanupfcn] = config_progress(progressopt,glopts)
%   Sets up progress function

% Copyright 2015 Takeshi Ikuma
% History:
% rev. - : (04-06-2015) original release

narginchk(1,2)

% get progress file location
progfile = '';
if ~(isempty(progressopt) || strcmpi(progressopt,'none'))
   progfile = fullfile(tempdir,'ffmpegprogress.txt');
%    progfile = fullfile(pwd,'ffmpeg_progress.txt');
   if exist(progfile,'file')
      delete(progfile);
   end
   glopts.progress = ['"' progfile '"'];
end

startfcn = @(infile,range,fs)starttimer(progressopt,progfile,infile,range,fs);
cleanupfcn = @(tobj)cleanup(tobj,progfile,progressopt);

end

function tobj = starttimer(progfcn,progfile,infile,range,fs)

tobj = [];

% if progress file not specified, progress not to be displayed
if isempty(progfile), return; end

try
   if isempty(range) && isempty(fs) % neither are specified
      [fs,T] = getframerate(infile);
   elseif isempty(range) % & ~isempty(fs)
      [fs0,T] = getframerate(infile);
      T = T*fs0/fs;
   else
      if isempty(fs) % & ~isempty(range)
         fs = getframerate(infile);
      end
      T = diff(range);
   end
   N = round(T*fs); % # of frames to be encoded
catch % audio coding does not produce trackable data so no progress bar to be shown
   return;
end

tobj = timer('ExecutionMode','fixedRate','Period',1,'TasksToExecute',inf);
if strcmpi(progfcn,'default')
   set(tobj,'TimerFcn',@(~,~)progfcn_default(progfile,N));
   progfcn_default('setup');
elseif isa(progfcn,'function_handle')
   set(tobj,'TimerFcn',{progfcn,progfile,N});
else
   error('ProgressFcn must be given as a function handle object.');
end

start(tobj);

end

function progfcn_default(progfile,N)
persistent pos
persistent h

switch progfile
   case 'setup'
      pos = 0;
      h = waitbar(0,'Searching for the starting frame...','WindowStyle','modal',...
         'Name',mfilename,'CloseRequestFcn',{});
      drawnow;
   case 'delete'
      delete(h);
   otherwise
      
      fid = fopen(progfile,'r');
      if fid<0, return; end % file not ready
      txt = '';
      try
         fseek(fid,pos,-1); % go to the last position
         txt = fscanf(fid,'%c',inf); % read all the text to the end
         pos = ftell(fid); % save the last position
         fclose(fid);
      catch % just in case
         fclose(fid);
      end
      
      toks = regexp(txt,'frame=(\d+)\n','tokens');
      if ~isempty(toks)
         val = str2double(toks{end}{1});
         if val>0
            waitbar(val/N,h,'Video transcoding in progress...');
            drawnow;
         end
      end
end
end

function cleanup(tobj,progfile,optval)
   % errored out, clear progress file
   if ~isempty(tobj)
      stop(tobj);
      delete(tobj);
   end
   if exist(progfile,'file')
      delete(progfile);
      if strcmp(optval,'default')
         progfcn_default('delete');
      end
   end
end
