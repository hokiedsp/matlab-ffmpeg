%mexClass Example MATLAB class wrapper to an underlying C++ class
classdef mexClass_demo < handle
    properties (Dependent)
        VarA
        VarB
        VarC
    end
    properties (SetAccess = private, Hidden = true)
        backend % Handle to the backend C++ class instance
    end
    methods (Static, Access = private, Hidden = true)
        varargout = mexClass_demo_backend(varargin)
    end
    methods (Static)
       function static_fcn()
          mexClass_demo.mexClass_demo_backend([],'static','static_fcn');
       end
    end
    methods
        %% Constructor - Create a new C++ class instance
        function obj = mexClass_demo(varargin)
            try
                obj.backend = mexClass_demo.mexClass_demo_backend(varargin{:});
            catch ME
                clear mexClass_demo.mexClass_demo_backend
                ME.rethrow()
            end
        end
        
        %% Destructor - Destroy the C++ class instance
        function delete(obj)
            mexClass_demo.mexClass_demo_backend(obj.backend, 'delete');
        end
        
        %% Train - an example class method call
        function varargout = train(obj, varargin)
            [varargout{1:nargout}] = mexClass_demo.mexClass_demo_backend(obj.backend, 'train', varargin{:});
        end
        
        %% Test - another example class method call
        function varargout = test(obj, varargin)
            [varargout{1:nargout}] = mexClass_demo.mexClass_demo_backend(obj.backend, 'test', varargin{:});
        end
        
        function val = get.VarA(obj)
            val = mexClass_demo.mexClass_demo_backend(obj.backend,'get','VarA');
        end
        function val = get.VarB(obj)
            val = mexClass_demo.mexClass_demo_backend(obj.backend,'get','VarB');
        end
        function val = get.VarC(obj)
            val = mexClass_demo.mexClass_demo_backend(obj.backend,'get','VarC');
        end
        
        function set.VarA(obj,val)
            mexClass_demo.mexClass_demo_backend(obj.backend,'set','VarA',val);
        end
        function set.VarB(obj,val)
            mexClass_demo.mexClass_demo_backend(obj.backend,'set','VarB',val);
        end
        function set.VarC(obj,val)
            mexClass_demo.mexClass_demo_backend(obj.backend,'set','VarC',val);
        end
    end
end
