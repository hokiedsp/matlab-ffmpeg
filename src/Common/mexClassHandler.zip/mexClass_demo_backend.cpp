#include "mex.h"
#include "mexClassHandler.h"

#include <vector>
#include <algorithm>

// The class that we are interfacing to
class dummy : public mexFunctionClass
{
public:
  dummy(int nrhs, const mxArray *prhs[]) : VarA(1), VarB({1.0f, 2.0f, 3.0f}), VarC("StringVar")
  {
    // accept property name-value pairs as input, throws exception if invalid property given
    set_props(nrhs, prhs);
  }

  static std::string get_componentid() { return "dummy"; }

  static bool static_handler(std::string command, int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
  {
    if (command=="static_fcn")
      dummy::static_fcn(nlhs,plhs,nrhs,prhs);
    else
      return false;
    return true;
  }

  bool action_handler(const std::string &command, int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
  {
    // try the base class action (set & get) first, returns true if action has been performed
    if (mexFunctionClass::action_handler(command, nlhs, plhs, nrhs, prhs))
      return true;

    if (command == "train")
    {
      // validate the arguments
      if (nlhs != 0 || nrhs != 0)
        mexErrMsgIdAndTxt((get_componentid() + ":train:invalidArguments").c_str(), "Train command takes no additional input argument and produces no output argument.");
      // run the action
      train();
    }
    else if (command == "test")
    {
      int id;

      // validate the arguments
      if (nlhs != 0 || nrhs != 1)
        mexErrMsgIdAndTxt((get_componentid() + ":test:invalidArguments").c_str(), "Test command takes one additional input argument and produces no output argument.");

      try
      {
        if (!(mxIsNumeric(prhs[0]) && mxIsScalar(prhs[0])) || mxIsComplex(prhs[0]))
          throw 0;
        double val = mxGetScalar(prhs[0]);
        id = (int)val;
        if (id != val)
          throw 0;
      }
      catch (...)
      {
        mexErrMsgIdAndTxt((get_componentid() + ":test:invalidArguments").c_str(), "ID input must be an integer.");
      }

      // run the action
      test(id);
    }
    else
      return false;
    return true;
  }

protected:
  void set_prop(const std::string name, const mxArray *value)
  {
    if (name == "VarA") // integer between -10 and 10
    {
      try
      {
        if (!(mxIsNumeric(value) && mxIsScalar(value)) || mxIsComplex(value))
          throw 0;
        double val = mxGetScalar(value);
        int temp = (int)val;
        if (temp != val || temp < -10 || temp > 10)
          throw 0;
        VarA = temp;
      }
      catch (...)
      {
        throw std::runtime_error("VarA must be a scalar integer between -10 and 10.");
      }
    }
    else if (name == "VarB")
    {
      try
      {
        if (!mxIsDouble(value) || mxIsComplex(value))
          throw 0;
        if (mxIsEmpty(value))
        {
          VarB.clear();
        }
        else
        {
          mwSize ndims = mxGetNumberOfDimensions(value);
          const mwSize *dims = mxGetDimensions(value);
          if (ndims > 2 || (dims[0] > 1 && dims[1] > 1))
            throw 0;
          mwSize dim = dims[0] == 1 ? dims[1] : dims[0];
          double *d_val = mxGetPr(value);
          VarB.reserve(dim);
          std::copy_n(d_val, dim, VarB.begin());
        }
      }
      catch (...)
      {
        throw std::runtime_error("VarB must be a vector of (real) doubles.");
      }
    }
    else if (name == "VarC")
    {
      if (mxGetM(value) != 1)
        throw std::runtime_error("VarC does not support multi-row string.");
      try
      {
        VarC = mexGetString(value);
      }
      catch (...)
      {
        throw std::runtime_error("VarC must be a character string.");
      }
    }
    else
    {
      throw std::runtime_error(std::string("Unknown property name:") + name);
    }
  }

  mxArray *get_prop(const std::string name)
  {
    mxArray *rval;
    if (name == "VarA") // integer between -10 and 10
    {
      rval = mxCreateDoubleScalar((double)VarA);
    }
    else if (name == "VarB")
    {
      rval = mxCreateDoubleMatrix(VarB.size(), 1, mxREAL);
      std::copy(VarB.begin(), VarB.end(), mxGetPr(rval));
    }
    else if (name == "VarC")
    {
      rval = mxCreateString(VarC.c_str());
    }
    else
    {
      throw std::runtime_error(std::string("Unknown property name:") + name);
    }
    return rval;
  }

private:
  // dummy variables and functions
  int VarA;
  std::vector<double> VarB;
  std::string VarC;

  void train() { mexPrintf("Executing train()\n"); }
  void test(int id) { mexPrintf("Executing test(%d)\n", id); }
  static void static_fcn(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) { mexPrintf("Executing static function\n"); }
};

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  mexClassHandler<dummy>(nlhs, plhs, nrhs, prhs);
}
